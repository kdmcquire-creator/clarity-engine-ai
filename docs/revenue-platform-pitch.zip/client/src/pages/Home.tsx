/* ============================================================
   HOME PAGE — Manus × Revenue Platform Strategy Pitch
   Design: Neo-Futurist Command Center
   Dark navy base, electric blue/cyan accents, Syne ExtraBold,
   interactive Recharts, animated counters, diagonal cuts.
   ============================================================ */

import { useState, useEffect, useRef } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  RadarChart, PolarGrid, PolarAngleAxis, Radar,
  AreaChart, Area, LineChart, Line, Legend
} from "recharts";

// ─── Data ────────────────────────────────────────────────────────────────────

const platforms = [
  { name: "AI Tool Directory", tier: 1, speedWeeks: 3, ceilingMin: 10, ceilingMax: 80, buildDays: 2, durability: 5 },
  { name: "Niche Comparison Site", tier: 1, speedWeeks: 4, ceilingMin: 15, ceilingMax: 100, buildDays: 3, durability: 5 },
  { name: "Free Tool Cluster", tier: 1, speedWeeks: 2, ceilingMin: 5, ceilingMax: 40, buildDays: 1, durability: 5 },
  { name: "Micro-SaaS Tool", tier: 1, speedWeeks: 1, ceilingMin: 5, ceilingMax: 50, buildDays: 3, durability: 5 },
  { name: "Lead Gen Site", tier: 1, speedWeeks: 2, ceilingMin: 10, ceilingMax: 60, buildDays: 2, durability: 5 },
  { name: "Programmatic Blog", tier: 2, speedWeeks: 6, ceilingMin: 8, ceilingMax: 60, buildDays: 3, durability: 5 },
  { name: "Niche Job Board", tier: 2, speedWeeks: 3, ceilingMin: 5, ceilingMax: 30, buildDays: 2, durability: 5 },
  { name: "Digital Product Store", tier: 2, speedWeeks: 1, ceilingMin: 3, ceilingMax: 25, buildDays: 2, durability: 5 },
  { name: "Newsletter Platform", tier: 2, speedWeeks: 6, ceilingMin: 5, ceilingMax: 40, buildDays: 1, durability: 5 },
  { name: "Course Platform", tier: 2, speedWeeks: 3, ceilingMin: 5, ceilingMax: 30, buildDays: 3, durability: 5 },
];

const radarData = [
  { subject: "Build Speed", Manus: 95, "Human Dev": 40, "Standard LLM": 55 },
  { subject: "Code Quality", Manus: 88, "Human Dev": 85, "Standard LLM": 60 },
  { subject: "Autonomy", Manus: 95, "Human Dev": 30, "Standard LLM": 25 },
  { subject: "SEO Content", Manus: 90, "Human Dev": 50, "Standard LLM": 75 },
  { subject: "Maintenance", Manus: 85, "Human Dev": 70, "Standard LLM": 20 },
  { subject: "Integrations", Manus: 88, "Human Dev": 80, "Standard LLM": 45 },
];

const roadmapData = [
  { week: "Wk 1-2", platforms: 3, cumulativeRevenue: 0, label: "Foundation" },
  { week: "Wk 3-4", platforms: 3, cumulativeRevenue: 2, label: "Revenue Accel" },
  { week: "Wk 5-6", platforms: 3, cumulativeRevenue: 8, label: "Diversification" },
  { week: "Wk 7-8", platforms: 3, cumulativeRevenue: 22, label: "High Ceiling" },
];

const revenueStackData = [
  { month: "M1", affiliate: 800, ads: 0, leadgen: 200, saas: 0, sponsored: 0 },
  { month: "M2", affiliate: 2200, ads: 400, leadgen: 600, saas: 400, sponsored: 0 },
  { month: "M3", affiliate: 4500, ads: 1200, leadgen: 1500, saas: 1200, sponsored: 500 },
  { month: "M4", affiliate: 7000, ads: 2800, leadgen: 3000, saas: 3500, sponsored: 1500 },
  { month: "M5", affiliate: 10000, ads: 5000, leadgen: 5000, saas: 7000, sponsored: 3000 },
  { month: "M6", affiliate: 14000, ads: 8000, leadgen: 7000, saas: 12000, sponsored: 5000 },
];

const capabilities = [
  {
    icon: "⚡",
    title: "True End-to-End Autonomy",
    description: "I don't just write code snippets — I operate a full sandboxed virtual machine. I scaffold the project, write logic, run tests, read error logs, fix bugs, and interact with deployment APIs without human intervention.",
    metric: "100%",
    metricLabel: "Autonomous execution",
    color: "blue",
  },
  {
    icon: "🔗",
    title: "Native API & Stripe Integration",
    description: "For Micro-SaaS and API Wrapper platforms, I autonomously integrate Stripe subscriptions, authentication flows, and third-party APIs like OpenAI — reading documentation and testing in my sandbox.",
    metric: "2-4 days",
    metricLabel: "Full SaaS with auth + payments",
    color: "cyan",
  },
  {
    icon: "📈",
    title: "Programmatic SEO at Scale",
    description: "I gather data on hundreds of products, structure it into databases, write programmatic templates, and generate unique SEO-optimized content for every page — the entire pipeline from data to deployment.",
    metric: "500+",
    metricLabel: "Pages generated per session",
    color: "green",
  },
  {
    icon: "🔄",
    title: "Scheduled Maintenance & Growth",
    description: "I can be scheduled to run recurring tasks: checking uptime, adding new tools to directories, generating fresh programmatic pages, and analyzing analytics to suggest CRO improvements.",
    metric: "24/7",
    metricLabel: "Autonomous maintenance",
    color: "blue",
  },
  {
    icon: "🚀",
    title: "Zero-Cost Failure & Rapid Pivoting",
    description: "Because I initialize full-stack projects in seconds and build core logic in hours, the cost of testing a new platform idea approaches zero. Place more bets, find winners faster.",
    metric: "3-5x",
    metricLabel: "Faster than human developer",
    color: "cyan",
  },
  {
    icon: "🧠",
    title: "Content Intelligence",
    description: "I generate high-quality, unique content for programmatic blogs and comparison sites — not thin AI slop, but researched, structured content that satisfies search intent and avoids penalties.",
    metric: "5,000+",
    metricLabel: "Articles per content site",
    color: "green",
  },
];

const manusVsOthers = [
  { capability: "Full-stack build (no copy-paste)", manus: true, chatgpt: false, humanDev: true },
  { capability: "Autonomous bug fixing", manus: true, chatgpt: false, humanDev: true },
  { capability: "Scheduled recurring tasks", manus: true, chatgpt: false, humanDev: false },
  { capability: "Stripe + Auth integration", manus: true, chatgpt: false, humanDev: true },
  { capability: "Programmatic SEO pipeline", manus: true, chatgpt: false, humanDev: true },
  { capability: "1-3 day deployment cadence", manus: true, chatgpt: false, humanDev: false },
  { capability: "Deploy 3-5 platforms/week", manus: true, chatgpt: false, humanDev: false },
  { capability: "Zero human routing needed", manus: true, chatgpt: false, humanDev: false },
  { capability: "Cost scales with output", manus: true, chatgpt: false, humanDev: false },
  { capability: "24/7 maintenance", manus: true, chatgpt: false, humanDev: false },
];

// ─── Animated Counter ─────────────────────────────────────────────────────────

function AnimatedCounter({ target, prefix = "", suffix = "", duration = 1800 }: {
  target: number; prefix?: string; suffix?: string; duration?: number;
}) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const start = performance.now();
          const animate = (now: number) => {
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(Math.floor(eased * target));
            if (progress < 1) requestAnimationFrame(animate);
          };
          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, duration]);

  return <span ref={ref}>{prefix}{count.toLocaleString()}{suffix}</span>;
}

// ─── Custom Tooltip ───────────────────────────────────────────────────────────

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="glow-card rounded-lg p-3 text-sm">
        <p className="font-semibold text-white mb-1">{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} style={{ color: p.color }}>
            {p.name}: <span className="font-mono-stat font-medium">{typeof p.value === 'number' && p.value >= 1000 ? `$${(p.value/1000).toFixed(0)}K` : p.value}</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

// ─── Section Wrapper ──────────────────────────────────────────────────────────

function Section({ children, className = "", id, style }: { children: React.ReactNode; className?: string; id?: string; style?: React.CSSProperties }) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={ref}
      id={id}
      style={style}
      className={`transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"} ${className}`}
    >
      {children}
    </section>
  );
}

// ─── Platform Filter ──────────────────────────────────────────────────────────

function PlatformExplorer() {
  const [activeTier, setActiveTier] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<"ceiling" | "speed" | "build">("ceiling");

  const filtered = platforms
    .filter(p => activeTier === null || p.tier === activeTier)
    .sort((a, b) => {
      if (sortBy === "ceiling") return b.ceilingMax - a.ceilingMax;
      if (sortBy === "speed") return a.speedWeeks - b.speedWeeks;
      return a.buildDays - b.buildDays;
    });

  const chartData = filtered.map(p => ({
    name: p.name.length > 18 ? p.name.slice(0, 16) + "…" : p.name,
    fullName: p.name,
    min: p.ceilingMin,
    max: p.ceilingMax,
    tier: p.tier,
  }));

  return (
    <div>
      {/* Controls */}
      <div className="flex flex-wrap gap-3 mb-6">
        <div className="flex gap-2">
          {[null, 1, 2, 3].map(t => (
            <button
              key={t ?? "all"}
              onClick={() => setActiveTier(t)}
              className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                activeTier === t
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-900/50"
                  : "bg-white/5 text-white/60 hover:bg-white/10"
              }`}
            >
              {t === null ? "All Tiers" : `Tier ${t}`}
            </button>
          ))}
        </div>
        <div className="flex gap-2 ml-auto">
          <span className="text-white/40 text-xs self-center">Sort by:</span>
          {[["ceiling", "Revenue"], ["speed", "Speed"], ["build", "Build Time"]] .map(([val, label]) => (
            <button
              key={val}
              onClick={() => setSortBy(val as any)}
              className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                sortBy === val
                  ? "bg-cyan-600/80 text-white"
                  : "bg-white/5 text-white/60 hover:bg-white/10"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
          <XAxis
            dataKey="name"
            tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 10, fontFamily: "Inter" }}
            angle={-35}
            textAnchor="end"
            interval={0}
          />
          <YAxis
            tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11, fontFamily: "Fira Code" }}
            tickFormatter={v => `$${v}K`}
          />
          <Tooltip content={<CustomTooltip />} />
          <Bar dataKey="min" name="Min Revenue" fill="rgba(37,99,235,0.5)" radius={[2, 2, 0, 0]} />
          <Bar dataKey="max" name="Max Revenue" fill="rgba(6,182,212,0.8)" radius={[2, 2, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
      <p className="text-center text-white/30 text-xs mt-2">Monthly revenue ceiling range (USD) — click tier buttons to filter</p>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function Home() {
  const [activeTab, setActiveTab] = useState<"roadmap" | "stack" | "comparison">("roadmap");

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">

      {/* ── NAV ── */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-white/8">
        <div className="container flex items-center justify-between h-14">
          <div className="flex items-center gap-2">
            <div className="pulse-dot" />
            <span className="font-bold text-sm tracking-widest uppercase" style={{ fontFamily: "Syne, sans-serif" }}>
              <span className="text-electric">Manus</span>
              <span className="text-white/40 mx-1">×</span>
              <span className="text-white/70">Revenue OS</span>
            </span>
          </div>
          <div className="hidden md:flex items-center gap-6 text-xs text-white/50">
            {["The Case", "Capabilities", "Platforms", "Roadmap", "Comparison"].map(s => (
              <a key={s} href={`#${s.toLowerCase().replace(" ", "-")}`} className="hover:text-cyan-400 transition-colors">
                {s}
              </a>
            ))}
          </div>
        </div>
      </nav>

      {/* ── HERO ── */}
      <div className="relative min-h-screen flex items-center pt-14">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663414931180/JzRyGeYr9FgtzFYFaaCP64/hero-bg-KfexCBDwBiJasbGL4dXGkn.webp)` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
        <div className="absolute inset-0 dot-grid opacity-20" />

        <div className="relative container py-20">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-600/20 border border-blue-500/40 text-blue-300 text-xs font-semibold mb-6 tracking-widest uppercase">
              <div className="pulse-dot w-1.5 h-1.5" />
              Revenue Platform Strategy — AI Execution Analysis
            </div>

            <h1 className="text-5xl md:text-7xl font-extrabold leading-tight mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
              <span className="gradient-text">Your Strategy</span>
              <br />
              <span className="text-white">Was Built</span>
              <br />
              <span className="text-white/60">for a Machine.</span>
            </h1>

            <p className="text-lg md:text-xl text-white/70 max-w-2xl mb-10 leading-relaxed">
              Autonomous monetization. Compounding traffic. Stackable revenue layers. 3-5 platforms per week.
              This is not a strategy for a developer — it is a strategy for an AI agent with a sandboxed computer.
              That agent is <strong className="text-cyan-400">Manus</strong>.
            </p>

            {/* Hero Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
              {[
                { label: "Platforms in Strategy", value: 20, suffix: "" },
                { label: "Max Monthly Revenue", value: 100, prefix: "$", suffix: "K+" },
                { label: "Deploy Cadence", value: 5, suffix: "/wk" },
                { label: "Autonomous Execution", value: 100, suffix: "%" },
              ].map((stat, i) => (
                <div key={i} className="glow-card rounded-xl p-4 text-center">
                  <div className="text-3xl font-extrabold font-mono-stat text-electric mb-1">
                    <AnimatedCounter target={stat.value} prefix={stat.prefix} suffix={stat.suffix} />
                  </div>
                  <div className="text-white/50 text-xs">{stat.label}</div>
                </div>
              ))}
            </div>

            <a
              href="#the-case"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm transition-all shadow-lg shadow-blue-900/50 hover:shadow-blue-900/80"
            >
              See the Full Case
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M8 3L13 8L8 13M3 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </a>
          </div>
        </div>
      </div>

      {/* ── THE CASE ── */}
      <Section id="the-case" className="py-24 bg-background">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <div className="text-xs text-cyan-400 font-semibold tracking-widest uppercase mb-3">The Core Argument</div>
            <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
              Why Manus is the Only Logical Choice
            </h2>
            <p className="text-white/60 text-lg leading-relaxed">
              Your strategy document has four non-negotiable operating principles. Each one maps directly to a core Manus capability — not as a workaround, but as a native design feature.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                principle: "Autonomous Monetization",
                description: "Revenue must flow without human involvement.",
                manusAnswer: "I build, deploy, and maintain platforms without a human acting as the 'router' between AI output and production code. I execute shell commands, fix errors, integrate payment APIs, and push to deployment — end-to-end.",
                icon: "🤖",
              },
              {
                principle: "Compounding Traffic",
                description: "SEO + content builds organic reach over time.",
                manusAnswer: "I run the full programmatic SEO pipeline: data gathering, database structuring, template generation, and unique content creation at scale. I can generate 500+ SEO pages in a single session and schedule weekly content refreshes.",
                icon: "📊",
              },
              {
                principle: "Stackable Revenue Layers",
                description: "Each platform runs 2-4 simultaneous income streams.",
                manusAnswer: "I natively integrate Stripe (subscriptions + one-time), affiliate link management, lead capture forms, and display ad placement — all in a single build session. No separate contractor needed for each layer.",
                icon: "💰",
              },
              {
                principle: "Deployable in 1-3 Days",
                description: "Scoped to ship fast, then grow.",
                manusAnswer: "I initialize a full-stack project (React + database + auth) in seconds. Core logic for Tier 1 platforms takes hours. The 1-3 day target is not aspirational for me — it is the default. For simpler platforms, I can deliver in under 4 hours.",
                icon: "🚀",
              },
            ].map((item, i) => (
              <div key={i} className="glow-card rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="text-3xl flex-shrink-0">{item.icon}</div>
                  <div>
                    <div className="text-xs text-white/40 uppercase tracking-widest mb-1">Your Principle</div>
                    <h3 className="text-lg font-bold text-white mb-1" style={{ fontFamily: "Syne, sans-serif" }}>{item.principle}</h3>
                    <p className="text-white/50 text-sm italic mb-3">"{item.description}"</p>
                    <div className="text-xs text-cyan-400 uppercase tracking-widest mb-1">Manus Response</div>
                    <p className="text-white/75 text-sm leading-relaxed">{item.manusAnswer}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ── CAPABILITIES ── */}
      <Section id="capabilities" className="py-24" style={{ background: "oklch(0.11 0.022 260)" }}>
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <div className="text-xs text-cyan-400 font-semibold tracking-widest uppercase mb-3">What I Actually Do</div>
            <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
              Six Capabilities That Change the Equation
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {capabilities.map((cap, i) => (
              <div key={i} className={`${cap.color === "cyan" ? "glow-card-cyan" : "glow-card"} rounded-2xl p-6 group`}>
                <div className="text-3xl mb-4">{cap.icon}</div>
                <h3 className="text-base font-bold text-white mb-2" style={{ fontFamily: "Syne, sans-serif" }}>{cap.title}</h3>
                <p className="text-white/60 text-sm leading-relaxed mb-4">{cap.description}</p>
                <div className="border-t border-white/8 pt-4 flex items-end justify-between">
                  <div>
                    <div className={`text-2xl font-extrabold font-mono-stat ${cap.color === "cyan" ? "text-cyan-glow" : cap.color === "green" ? "text-green-glow" : "text-electric"}`}>
                      {cap.metric}
                    </div>
                    <div className="text-white/40 text-xs">{cap.metricLabel}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Radar Chart */}
          <div className="mt-16 glow-card rounded-2xl p-8">
            <h3 className="text-xl font-bold text-white text-center mb-8" style={{ fontFamily: "Syne, sans-serif" }}>
              Capability Comparison: Manus vs. Alternatives
            </h3>
            <ResponsiveContainer width="100%" height={350}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="rgba(255,255,255,0.1)" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 12, fontFamily: "Inter" }} />
                <Radar name="Manus" dataKey="Manus" stroke="#2563EB" fill="#2563EB" fillOpacity={0.3} strokeWidth={2} />
                <Radar name="Human Dev" dataKey="Human Dev" stroke="#06B6D4" fill="#06B6D4" fillOpacity={0.15} strokeWidth={1.5} strokeDasharray="4 2" />
                <Radar name="Standard LLM" dataKey="Standard LLM" stroke="rgba(255,255,255,0.3)" fill="rgba(255,255,255,0.05)" strokeWidth={1} strokeDasharray="2 3" />
                <Legend wrapperStyle={{ color: "rgba(255,255,255,0.6)", fontSize: 12 }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </Section>

      {/* ── PLATFORMS ── */}
      <Section id="platforms" className="py-24 bg-background">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <div className="text-xs text-cyan-400 font-semibold tracking-widest uppercase mb-3">The 20-Platform Portfolio</div>
            <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
              Explore Revenue Potential by Platform
            </h2>
            <p className="text-white/60">Filter and sort the 20 platforms by revenue ceiling, speed to revenue, or build time. The bars show the min/max monthly revenue range at scale.</p>
          </div>

          <div className="glow-card rounded-2xl p-6 md:p-8 mb-8">
            <PlatformExplorer />
          </div>

          {/* Platform cards by tier */}
          <div className="space-y-8">
            {[
              { tier: 1, label: "Tier 1 — Core Machines", desc: "Deploy first. High ceiling, proven, SEO-compoundable, affiliate-native.", color: "blue" },
              { tier: 2, label: "Tier 2 — High-Conviction Builds", desc: "Slightly more complex, higher upside, strong compounding.", color: "cyan" },
            ].map(({ tier, label, desc, color }) => (
              <div key={tier}>
                <div className="flex items-center gap-3 mb-4">
                  <span className={`px-3 py-1 rounded text-xs font-bold ${color === "blue" ? "tier-badge-1" : "tier-badge-2"}`}>
                    {label}
                  </span>
                  <span className="text-white/40 text-sm">{desc}</span>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {platforms.filter(p => p.tier === tier).map((p, i) => (
                    <div key={i} className="glow-card rounded-xl p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="text-sm font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>{p.name}</h4>
                        <span className={`text-xs font-mono-stat ${color === "blue" ? "text-electric" : "text-cyan-glow"}`}>
                          ${p.ceilingMin}K–${p.ceilingMax}K
                        </span>
                      </div>
                      <div className="flex gap-4 text-xs text-white/40">
                        <span>⏱ {p.speedWeeks}wk to revenue</span>
                        <span>🔨 {p.buildDays}d build</span>
                      </div>
                      {/* Durability stars */}
                      <div className="flex gap-0.5 mt-2">
                        {Array.from({ length: 5 }).map((_, si) => (
                          <div key={si} className={`h-1 w-4 rounded-full ${si < p.durability ? (color === "blue" ? "bg-blue-500" : "bg-cyan-500") : "bg-white/10"}`} />
                        ))}
                        <span className="text-white/30 text-xs ml-1">durability</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ── ROADMAP ── */}
      <Section id="roadmap" className="py-24" style={{ background: "oklch(0.11 0.022 260)" }}>
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <div className="text-xs text-cyan-400 font-semibold tracking-widest uppercase mb-3">8-Week Execution Plan</div>
            <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
              From Zero to Revenue Portfolio
            </h2>
          </div>

          {/* Tab switcher */}
          <div className="flex gap-2 mb-8 justify-center">
            {[["roadmap", "Deployment Timeline"], ["stack", "Revenue Stack Growth"], ["comparison", "Manus vs. Alternatives"]].map(([key, label]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key as any)}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                  activeTab === key
                    ? "bg-blue-600 text-white shadow-lg shadow-blue-900/50"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="glow-card rounded-2xl p-6 md:p-8">
            {activeTab === "roadmap" && (
              <div>
                <h3 className="text-lg font-bold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
                  Platforms Deployed + Cumulative Revenue Potential (Weeks 1-8)
                </h3>
                <ResponsiveContainer width="100%" height={320}>
                  <BarChart data={roadmapData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="week" tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 12 }} />
                    <YAxis yAxisId="left" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11, fontFamily: "Fira Code" }} />
                    <YAxis yAxisId="right" orientation="right" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11, fontFamily: "Fira Code" }} tickFormatter={v => `$${v}K`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend wrapperStyle={{ color: "rgba(255,255,255,0.6)", fontSize: 12 }} />
                    <Bar yAxisId="left" dataKey="platforms" name="Platforms Deployed" fill="rgba(37,99,235,0.8)" radius={[4, 4, 0, 0]} />
                    <Bar yAxisId="right" dataKey="cumulativeRevenue" name="Est. Monthly Revenue ($K)" fill="rgba(6,182,212,0.7)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
                {/* Timeline cards */}
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
                  {[
                    { weeks: "Weeks 1-2", phase: "Foundation", platforms: ["AI Tool Directory (Legal)", "Free Tool Cluster (10-15 tools)", "Niche Comparison Site"], color: "blue" },
                    { weeks: "Weeks 3-4", phase: "Revenue Acceleration", platforms: ["Micro-SaaS #1 (LinkedIn Bio, $19/mo)", "Niche Job Board (AI/Remote)", "Digital Product Storefront"], color: "cyan" },
                    { weeks: "Weeks 5-6", phase: "Diversification", platforms: ["Lead Gen Site (Home Services)", "AI Tool Directory (Finance)", "Newsletter Platform"], color: "green" },
                    { weeks: "Weeks 7-8", phase: "High-Ceiling Builds", platforms: ["Micro-SaaS #2 (SEO Brief, $49/mo)", "Programmatic Blog", "API Wrapper Tool"], color: "blue" },
                  ].map((phase, i) => (
                    <div key={i} className="bg-white/5 rounded-xl p-4">
                      <div className={`text-xs font-bold uppercase tracking-widest mb-1 ${phase.color === "cyan" ? "text-cyan-glow" : phase.color === "green" ? "text-green-glow" : "text-electric"}`}>
                        {phase.weeks}
                      </div>
                      <div className="text-sm font-bold text-white mb-3" style={{ fontFamily: "Syne, sans-serif" }}>{phase.phase}</div>
                      <ul className="space-y-1">
                        {phase.platforms.map((p, pi) => (
                          <li key={pi} className="text-xs text-white/55 flex items-start gap-1.5">
                            <span className={`mt-1 w-1.5 h-1.5 rounded-full flex-shrink-0 ${phase.color === "cyan" ? "bg-cyan-500" : phase.color === "green" ? "bg-green-500" : "bg-blue-500"}`} />
                            {p}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "stack" && (
              <div>
                <h3 className="text-lg font-bold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
                  Stacked Revenue Growth by Layer (6-Month Projection)
                </h3>
                <ResponsiveContainer width="100%" height={350}>
                  <AreaChart data={revenueStackData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="month" tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 12 }} />
                    <YAxis tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11, fontFamily: "Fira Code" }} tickFormatter={v => `$${(v/1000).toFixed(0)}K`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend wrapperStyle={{ color: "rgba(255,255,255,0.6)", fontSize: 12 }} />
                    <Area type="monotone" dataKey="affiliate" name="Affiliate" stackId="1" stroke="#2563EB" fill="rgba(37,99,235,0.6)" />
                    <Area type="monotone" dataKey="ads" name="Display Ads" stackId="1" stroke="#06B6D4" fill="rgba(6,182,212,0.5)" />
                    <Area type="monotone" dataKey="leadgen" name="Lead Gen" stackId="1" stroke="#10B981" fill="rgba(16,185,129,0.4)" />
                    <Area type="monotone" dataKey="saas" name="SaaS MRR" stackId="1" stroke="#8B5CF6" fill="rgba(139,92,246,0.4)" />
                    <Area type="monotone" dataKey="sponsored" name="Sponsored" stackId="1" stroke="#F59E0B" fill="rgba(245,158,11,0.3)" />
                  </AreaChart>
                </ResponsiveContainer>
                <p className="text-white/30 text-xs text-center mt-3">Illustrative projection based on strategy document revenue ceilings. Actual results depend on execution, SEO, and market conditions.</p>
              </div>
            )}

            {activeTab === "comparison" && (
              <div>
                <h3 className="text-lg font-bold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
                  Manus vs. Standard LLM vs. Human Developer
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-white/10">
                        <th className="text-left py-3 pr-4 text-white/50 font-medium">Capability</th>
                        <th className="text-center py-3 px-4 text-electric font-bold" style={{ fontFamily: "Syne, sans-serif" }}>Manus</th>
                        <th className="text-center py-3 px-4 text-white/50 font-medium">Standard LLM</th>
                        <th className="text-center py-3 px-4 text-white/50 font-medium">Human Dev</th>
                      </tr>
                    </thead>
                    <tbody>
                      {manusVsOthers.map((row, i) => (
                        <tr key={i} className="border-b border-white/5 hover:bg-white/3 transition-colors">
                          <td className="py-3 pr-4 text-white/70">{row.capability}</td>
                          <td className="text-center py-3 px-4">
                            {row.manus ? (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 text-xs font-bold">✓</span>
                            ) : (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-red-900/30 text-red-400 text-xs">✗</span>
                            )}
                          </td>
                          <td className="text-center py-3 px-4">
                            {row.chatgpt ? (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-900/30 text-green-400 text-xs font-bold">✓</span>
                            ) : (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-red-900/30 text-red-400 text-xs">✗</span>
                            )}
                          </td>
                          <td className="text-center py-3 px-4">
                            {row.humanDev ? (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-900/30 text-green-400 text-xs font-bold">✓</span>
                            ) : (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-red-900/30 text-red-400 text-xs">✗</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-6 p-4 rounded-xl bg-blue-600/10 border border-blue-500/30">
                  <p className="text-white/70 text-sm leading-relaxed">
                    <strong className="text-white">The critical insight:</strong> A standard LLM gives you code that you still have to copy, paste, debug, and deploy yourself — making you the bottleneck.
                    A human developer has the autonomy but not the speed or cost profile to hit 3-5 platforms per week.
                    Manus is the only option that combines <span className="text-cyan-400">full autonomy</span>, <span className="text-blue-400">deployment speed</span>, and <span className="text-green-400">zero marginal cost per platform</span>.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </Section>

      {/* ── COMPARISON SECTION ── */}
      <Section id="comparison" className="py-24 bg-background">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="text-xs text-cyan-400 font-semibold tracking-widest uppercase mb-3">The Honest Assessment</div>
              <h2 className="text-4xl font-extrabold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
                What Makes This Different From Just Using ChatGPT?
              </h2>
              <p className="text-white/65 leading-relaxed mb-6">
                When you use a standard LLM to build a platform, you become the execution layer. You copy the code, open your IDE, install dependencies, debug the errors, set up the database, configure Stripe, and push to Vercel. You are the bottleneck.
              </p>
              <p className="text-white/65 leading-relaxed mb-6">
                With Manus, I <em>am</em> the execution layer. I have a real computer with a terminal, a browser, a code editor, and internet access. When I say "I'll build the Micro-SaaS tool," I mean I will open a terminal, scaffold the project, write the code, run it, read the error logs, fix the bugs, integrate Stripe, and hand you a working URL.
              </p>
              <p className="text-white/65 leading-relaxed">
                The difference is not incremental. It is the difference between having a <strong className="text-white">consultant who writes plans</strong> and having an <strong className="text-cyan-400">engineer who ships products</strong>.
              </p>
            </div>
            <div>
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663414931180/JzRyGeYr9FgtzFYFaaCP64/manus-brain-EG9hRtg6cSKJmiMxRA7Fbb.webp"
                alt="Manus AI neural network visualization"
                className="rounded-2xl w-full object-cover"
                style={{ border: "1px solid rgba(37,99,235,0.3)", boxShadow: "0 0 40px rgba(37,99,235,0.15)" }}
              />
            </div>
          </div>
        </div>
      </Section>

      {/* ── REVENUE GROWTH VISUAL ── */}
      <Section className="py-24" style={{ background: "oklch(0.11 0.022 260)" }}>
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663414931180/JzRyGeYr9FgtzFYFaaCP64/revenue-chart-art-i4xNuR56g8UtGaXcgSjzJf.webp"
                alt="Revenue growth visualization"
                className="rounded-2xl w-full object-cover"
                style={{ border: "1px solid rgba(6,182,212,0.3)", boxShadow: "0 0 40px rgba(6,182,212,0.1)" }}
              />
            </div>
            <div>
              <div className="text-xs text-cyan-400 font-semibold tracking-widest uppercase mb-3">The Compounding Effect</div>
              <h2 className="text-4xl font-extrabold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
                Each Platform Compounds the Next
              </h2>
              <p className="text-white/65 leading-relaxed mb-6">
                Your strategy is designed around compounding: SEO traffic builds over time, affiliate commissions recur monthly, and SaaS MRR stacks. But compounding only works if you can deploy fast enough to get the flywheel spinning.
              </p>
              <p className="text-white/65 leading-relaxed mb-8">
                At 3-5 platforms per week, by week 8 you have 12 live platforms. By month 3, the early platforms are generating organic traffic. By month 6, the SaaS tools have MRR. The entire model depends on the deployment velocity that only an autonomous AI agent can sustain.
              </p>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: "Week 8", value: "12", sub: "live platforms" },
                  { label: "Month 3", value: "$22K+", sub: "est. monthly" },
                  { label: "Month 6", value: "$46K+", sub: "est. monthly" },
                ].map((stat, i) => (
                  <div key={i} className="glow-card-cyan rounded-xl p-4 text-center">
                    <div className="text-xs text-white/40 mb-1">{stat.label}</div>
                    <div className="text-xl font-extrabold font-mono-stat text-cyan-glow">{stat.value}</div>
                    <div className="text-xs text-white/40">{stat.sub}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* ── CTA ── */}
      <Section className="py-24 bg-background">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <div className="text-xs text-cyan-400 font-semibold tracking-widest uppercase mb-4">Ready to Execute</div>
            <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-6" style={{ fontFamily: "Syne, sans-serif" }}>
              Tell Me Which Platform to Build First.
            </h2>
            <p className="text-white/65 text-lg leading-relaxed mb-10">
              My recommendation: the <strong className="text-white">Free Tool Cluster Site</strong> — fastest to rank, zero ad spend needed, affiliate-ready from day one, and I can deliver it in under 24 hours.
              But you have 19 other options, and I am ready to start on any of them immediately.
            </p>

            <div className="grid sm:grid-cols-3 gap-4 mb-10">
              {[
                { platform: "Free Tool Cluster", time: "< 1 day", revenue: "$5K–$40K/mo", recommended: true },
                { platform: "AI Tool Directory", time: "1-2 days", revenue: "$10K–$80K/mo", recommended: false },
                { platform: "Micro-SaaS Tool", time: "2-4 days", revenue: "$5K–$50K MRR", recommended: false },
              ].map((opt, i) => (
                <div key={i} className={`rounded-xl p-5 text-left relative ${opt.recommended ? "glow-card border-blue-500/60" : "glow-card"}`}>
                  {opt.recommended && (
                    <div className="absolute -top-2.5 left-4 px-2 py-0.5 bg-blue-600 text-white text-xs font-bold rounded">
                      Recommended
                    </div>
                  )}
                  <div className="text-sm font-bold text-white mb-2" style={{ fontFamily: "Syne, sans-serif" }}>{opt.platform}</div>
                  <div className="text-xs text-white/50 mb-1">⏱ Build time: <span className="text-electric font-mono-stat">{opt.time}</span></div>
                  <div className="text-xs text-white/50">💰 Ceiling: <span className="text-cyan-glow font-mono-stat">{opt.revenue}</span></div>
                </div>
              ))}
            </div>

            <p className="text-white/40 text-sm">
              Prepared by Manus AI · March 2026 · Based on Revenue Platform Strategy by Shane Mitchell (Feb 28, 2026)
            </p>
          </div>
        </div>
      </Section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-white/8 py-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="pulse-dot" />
            <span className="text-white/40 text-sm font-semibold" style={{ fontFamily: "Syne, sans-serif" }}>
              Manus × Revenue Platform Strategy
            </span>
          </div>
          <p className="text-white/25 text-xs text-center">
            This interactive presentation was autonomously built by Manus AI — demonstrating exactly the capability described herein.
          </p>
        </div>
      </footer>
    </div>
  );
}
